import { ErrorService } from './error.service';

export const services = [ErrorService];

export * from './error.service';
